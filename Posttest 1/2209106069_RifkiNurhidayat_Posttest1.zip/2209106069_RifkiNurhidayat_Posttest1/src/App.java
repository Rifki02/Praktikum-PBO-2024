import java.util.ArrayList;

import kopi.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class App {
    public static void main(String[] args) throws IOException {
        ArrayList<coffee> coffees = new ArrayList<>();
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);


        while (true) {
            System.out.println("Selamat Datang ");
            System.out.println("----------------------");
            System.out.println("1. Lihat Kopi");
            System.out.println("2. Tambah Kopi");
            System.out.println("3. Ubah Kopi");
            System.out.println("4. Hapus Kopi");
            System.out.println("5. Keluar");
            System.out.println("----------------------");
            System.out.print("Menu : ");
            int menu = Integer.parseInt(br.readLine());
            switch (menu) {
                case 1:
                    if (coffees.isEmpty()) {
                        System.out.println("Belum Ada Data Kopi");
                    } else {
                        System.out.println("---------------------------------------------------------");
                        System.out.printf("|%-4s| %-15s| %-15s| %-15s| %n", "No", "Nama Kopi", "Jenis Kopi", "Harga Kopi" );
                        for (int i = 0; i < coffees.size(); i++) {
                            coffee kopi = coffees.get(i);
                            String namaKopi = kopi.getNamaKopi();
                            String jenisKopi = kopi.getJenisKopi();
                            int jumlahKopi = kopi.getJumlahKopi();
                            System.out.println("---------------------------------------------------------");
                            System.out.printf("|%-4d| %-15s| %-15s| %-15d| %n", i + 1, namaKopi, jenisKopi, jumlahKopi);
                        }
                        System.out.println("---------------------------------------------------------");
                    }
                    break;
                case 2:
                    System.out.print("Masukkan Nama Kopi   : ");
                    String namaKopi = br.readLine();
                    System.out.print("Masukkan Jenis Kopi  : ");
                    String jenisKopi = br.readLine();
                    System.out.print("Masukkan Jumlah Kopi : ");
                    int jumlahKopi = Integer.parseInt(br.readLine());
                    coffee kopi = new coffee(namaKopi, jenisKopi, jumlahKopi);
                    coffees.add(kopi);
                    break;
                case 3:
                    System.out.println("Update Data Kopi");
                    System.out.print("Data Nomor Ke Berapa Yang Ingin Di Update? : ");
                    int cari = Integer.parseInt(br.readLine()) - 1;
                    for (int i = 0; i < coffees.size(); i++ ) {
                        if (cari == i) {
                            coffee kopiBaru = coffees.get(i);
                            System.out.print("Masukkan Nama Kopi Baru   : ");
                            String namaKopiBaru = br.readLine();
                            kopiBaru.setNamaKopi(namaKopiBaru);
                            System.out.print("Masukkan Jenis Kopi Baru  : ");
                            String jenisKopiBaru = br.readLine();
                            kopiBaru.setJenisKopi(jenisKopiBaru);
                            System.out.print("Masukkan Jumlah Kopi Baru : ");
                            int jumlahKopiBaru = Integer.parseInt(br.readLine());
                            kopiBaru.setJumlahKopi(jumlahKopiBaru);
                        }
                    }
                    break;
                case 4:
                    System.out.println("Hapus Data Pemain");
                    System.out.print("Data Nomor Ke Berapa Yang Ingin Di Hapus? : ");
                    int hapus = Integer.parseInt(br.readLine()) - 1;
                    coffees.remove(hapus);
                    break;
                case 5:
                    System.out.println("Terimakasih Telah Menggunakan Program Ini");
                    System.exit(0);
                    break;
            
                default:
                    break;
            }
        }
    }
}
