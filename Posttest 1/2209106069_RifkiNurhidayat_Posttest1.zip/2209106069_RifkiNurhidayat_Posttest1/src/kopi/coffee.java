package kopi;

public class coffee {
    String namaKopi;
    String jenisKopi;
    int jumlahKopi;

    public coffee(String namaKopi, String jenisKopi, int jumlahKopi){
        this.namaKopi = namaKopi;
        this.jenisKopi = jenisKopi;
        this.jumlahKopi = jumlahKopi;
    }

    public String getNamaKopi() {
        return namaKopi;
    }

    public String getJenisKopi() {
        return jenisKopi;
    }

    public int getJumlahKopi() {
        return jumlahKopi;
    }

    public void setNamaKopi(String namaKopi) {
        this.namaKopi = namaKopi;
    }

    public void setJenisKopi(String jenisKopi) {
        this.jenisKopi = jenisKopi;
    }

    public void setJumlahKopi(int jumlahKopi) {
        this.jumlahKopi = jumlahKopi;
    }
}
